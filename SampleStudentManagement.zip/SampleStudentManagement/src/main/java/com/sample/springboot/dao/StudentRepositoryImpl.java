//package com.sample.springboot.dao;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Optional;
//
//import javax.transaction.Transactional;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.domain.Example;
//import org.springframework.data.domain.Page;
//import org.springframework.data.domain.Pageable;
//import org.springframework.data.domain.Sort;
//import org.springframework.stereotype.Repository;
//
//import com.sample.springboot.dto.Student;
//
//// @Repository
//// @Transactional
//public class StudentRepositoryImpl {
//
//	@Autowired
//	private StudentRepository repository;
//	public List<Student> findAllStudents() {
//		List<Student> ls = new ArrayList<Student>();
//		return repository.findAll();
//	}
//	public void save(Student s) {
//		
//		 repository.save(s);
//		 System.out.println("Saved Data: " + s);
//	}
//          
//}
