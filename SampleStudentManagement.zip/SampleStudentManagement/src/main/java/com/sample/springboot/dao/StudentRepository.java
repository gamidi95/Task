package com.sample.springboot.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sample.springboot.dto.Student;
@Repository
public interface StudentRepository extends JpaRepository<Student, Long> {

	// public List<Student> findAll();
	// public <S extends Student> S save(S entity);
}
