package com.sample.springboot.service;

import java.util.List;

import com.sample.springboot.dto.Student;

public interface IStudentService {

	public void addStudent(Student s);
	public List<Student> getAllStudents();
	
}
