package com.sample.springboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sample.springboot.dto.Student;
import com.sample.springboot.service.StudentService;
import com.sample.springboot.validations.StudentValidation;

//import antlr.collections.List;

@RestController	
@RequestMapping("/student")
public class StudentController {
	
	@Autowired
	StudentService studentService;
	
	@PostMapping("/addstudent")
	public void addStudent(@RequestBody Student student) {
		boolean Valid = StudentValidation.validateStudent(student);
		if (!Valid)
		 studentService.addStudent(student);
		else
			System.out.println("Invalid Request");
		
		
	}
	@GetMapping("/getallstudents")
	public List<Student> getAllStd()  {
		
		return studentService.getAllStudents();
		
	}

}
