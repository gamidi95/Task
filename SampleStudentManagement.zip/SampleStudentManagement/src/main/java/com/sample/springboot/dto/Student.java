package com.sample.springboot.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.NotNull;

import lombok.Data;

//@Data
@Entity
@SequenceGenerator(name = "std_id", sequenceName = "std_id",  initialValue = 1000)
public class Student {

		@Id
		
		@GeneratedValue(strategy = GenerationType.AUTO, generator="std_id")
		private Long id;
		
		@Column
		@NotNull
		private String name;
		@Column
		private String city;
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getCity() {
			return city;
		}
		public void setCity(String city) {
			this.city = city;
		}
		@Override
		public String toString() {
			return "Student [id=" + id + ", name=" + name + ", city=" + city + "]";
		}
		
	
}
