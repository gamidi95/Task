package com.sample.springboot.validations;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;

import com.sample.springboot.dto.Student;
import com.sample.springboot.service.StudentService;


public class StudentValidation {
	
	@Autowired
	StudentService studentService;
	// if (studentValidator.validateStudent(s))
	public static Boolean validateStudent(Student s) {
		
		if (numValidation(s.getName()) || s.getName() == null || s.getName() == "" || s.getName().equalsIgnoreCase("")) {
			System.out.println("InValid Name");
		return true;	
		}
		
		return false;
		
	}
	
	
	static boolean numValidation(String name) {
		Pattern p = Pattern.compile("([0-9])");
		Matcher m = p.matcher(name);
		if(m.find()) {
				return true;	
				
		}else		
		return false;
	}

}
