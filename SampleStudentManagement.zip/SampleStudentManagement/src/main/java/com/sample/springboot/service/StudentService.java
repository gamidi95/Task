package com.sample.springboot.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sample.springboot.dao.StudentRepository;
//import com.sample.springboot.dao.StudentRepositoryImpl;
import com.sample.springboot.dto.Student;

@Service

public class StudentService implements IStudentService{

	@Autowired
	StudentRepository studentServiceImpl;
	
	@Override
	public void addStudent(Student s) {
		// TODO Auto-generated method stub
		System.out.println("Adding Student: ");
	
		studentServiceImpl.save(s);
		
		System.out.println(s);
	}

	
	@Override
	public List<Student> getAllStudents() {
		// TODO Auto-generated method stub
		// List<Student> ls = new ArrayList<Student>();
		return studentServiceImpl.findAll();
	}

}
