package com.sampleStudentClient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SampleStudentClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
