package com.sampleStudentClient.restHelper;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.sampleStudentClient.dto.Student;

@Component
public class RestHelper {

		
	public List<Student> getAllStudents() throws URISyntaxException {
		// TODO Auto-generated method stub
		// List<Student> ls = new ArrayList<Student>();
		
		RestTemplate restTemplate = new RestTemplate();
	     
		final String baseUrl = "http://localhost:9054/student/getallstudents";
		URI uri = new URI(baseUrl);
		 
		ResponseEntity<Student[]> result = restTemplate.getForEntity(uri, Student[].class);
		     
		//Verify request succeed
		
		return Arrays.asList(result.getBody());
	}

}
