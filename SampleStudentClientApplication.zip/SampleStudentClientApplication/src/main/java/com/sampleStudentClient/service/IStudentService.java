package com.sampleStudentClient.service;

import java.net.URISyntaxException;
import java.util.List;

import com.sampleStudentClient.dto.Student;

public interface IStudentService {

	
	public List<Student> getAllStudents() throws URISyntaxException;
	
}
