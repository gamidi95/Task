package com.sampleStudentClient.service;

import java.net.URISyntaxException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sampleStudentClient.dto.Student;
import com.sampleStudentClient.restHelper.RestHelper;

@Service

public class StudentService implements IStudentService{

	@Autowired
	RestHelper rh;
	@Override
	public List<Student> getAllStudents() throws URISyntaxException {
				
		return rh.getAllStudents();
	}

}
